
Documentation for users of your algebra module
Must contain usage of each function with examples...
...and also a lot of real life aspects to be solved using your module

You have to show them the importance of your module !!